﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Paging_the_devil.GameObjects
{
    class Character : MovingObject
    {
        public Character(Texture2D tex, Vector2 pos, Rectangle rect) : base(tex, pos, rect)
        {

        }

        public override void Update()
        {

        }

        public override void Draw(SpriteBatch spriteBatch)
        {

        }
    }
}
